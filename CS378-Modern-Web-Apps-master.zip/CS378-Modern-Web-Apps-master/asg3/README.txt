David Ko
dpk326

This assignment, even though extended, I could not get the full grasp on the idea of the spring framework due to complications with my Eclipse and the set up, but the time I had the set up finally working to get hello world working, it was already Thursday, the day before it was due. This is my best attempt at trying to finish the assignment.

It is very difficult to get the project directory/spring framework working (maven, dependecies and etc) even when folllowing along in class because when I go home and try it, i run into many different errors that were not present in class. 

I believe in class the professor should start the assignement projects examples from scratch and not from a working project so we can follow along easier and get help debugging as we run into errors as they happen instead of learning from a perfect project.