import java.net.URLConnection;

//this is the interfce tht hs the functions

public interface countService {
	
	//whtat functions should be in here for the project?

	//get the project nme for query
	public String getResponseFromEavesDrop(String projectName);	

	public void thisIsVoidFunction();
	
	public String outputTitle();
}
