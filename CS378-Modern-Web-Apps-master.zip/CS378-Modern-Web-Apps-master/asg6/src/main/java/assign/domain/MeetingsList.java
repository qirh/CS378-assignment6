package assign.domain;

public class MeetingsList {

	//do i need this?
	//i want to create a list of meetings so...
	//should that be done in meetings.java?
	
	
	
}
