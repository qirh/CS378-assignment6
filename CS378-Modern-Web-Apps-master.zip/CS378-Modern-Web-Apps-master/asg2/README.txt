David Ko
dpk326
Assignment 2
CS78 - Modern Web Applications

Repo structure:
assignment2/assignment2/<project from eclipse

not to be submit on canvas

assignment 2 was created in Eclipse Luna and the parsing was done with JSoup
the JSoup jar file was imported via the IDE into the WEB-INF/lib folder

FAULT IN MY PROGRAM:
cookies do not function the way i want them to work, couldn’t get them to be a key inside my visitedURLS map for saving past URLS, and since that doesn’t work, the visitedURL section only outputs the most recent URL. which really sucks.